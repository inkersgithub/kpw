<?php


function random($length)
{

	$chars = implode(range('a','z'));
	$chars .= implode(range('2','8'));
	$shuffled = str_shuffle($chars);
	return substr($shuffled, 0, $length);
}
function session_token()
{
	return random(8).random(8).random(8).random(8);
}

function pushMessage($tle,$mssg,$topics){
$msgdata = array (
                    "message" => $mssg,
                    "title"=>$tle
            );
$data = json_encode($msgdata);

    $url = 'https://fcm.googleapis.com/fcm/send';

    $fields = array (
            'to' => '/topics/'.$topics,
            'data' => array("data"=>$data)
    );
    $fields = json_encode ( $fields );

    $headers = array (
            'Authorization: key=' . "AAAAf3HRpGw:APA91bF-FsWVpVBMxUaKv7KmfytiomIrWftYdB5DWgBFUlWlZtXHm7J7xERghRCEDoHDr3_wABX9utWcWJz0cyoxmP-d-kr7aI92NClyWyrQIOF4QCLfIJ0udCuOrF19WZRgAUqs7A_p",
            'Content-Type: application/json'
    );

    $ch = curl_init ();
    curl_setopt ( $ch, CURLOPT_URL, $url );
    curl_setopt ( $ch, CURLOPT_POST, true );
    curl_setopt ( $ch, CURLOPT_HTTPHEADER, $headers );
    curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, true );
    curl_setopt ( $ch, CURLOPT_POSTFIELDS, $fields );

    $result = curl_exec ( $ch );
    curl_close ( $ch );
    //echo "<script>console.log('$result');</script>";
}



?>
