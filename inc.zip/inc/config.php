<?php
define("BASE","http://localhost/kpower");
define ("HOST","localhost");
define ("USER","root");
define ("PSD","");
define ("PWD","");
define ("DB","kpower");

?>